rootProject.name = "IntelliJ Platform Plugin Template"

plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"
}
