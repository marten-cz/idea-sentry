<!-- Keep a Changelog guide -> https://keepachangelog.com -->

# %NAME% Changelog

## [Unreleased]
### Added
- Initial scaffold created from [IntelliJ Platform Plugin Template](https://github.com/JetBrains/intellij-platform-plugin-template)
